//
//  HeartCountMeasureApp.swift
//  HeartCountMeasure
//
//  Created by Vivek Patel on 20/09/23.
//

import SwiftUI

@main
struct HeartCountMeasureApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
